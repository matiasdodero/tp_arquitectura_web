const mongoose = require('mongoose');

const peliculaSchema = new mongoose.Schema({
    titulo: String,
    fecha: Date,
    recaudacion: Number,
    asistentes: Number
});

const Pelicula = mongoose.model('Pelicula', peliculaSchema);

module.exports = Pelicula;
