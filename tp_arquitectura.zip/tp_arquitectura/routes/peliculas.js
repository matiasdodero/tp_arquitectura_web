const express = require('express');
const Pelicula = require('../models/Pelicula');
const router = express.Router();

// creacion de peli
router.post('/', async (req, res) => {
    try {
        const pelicula = new Pelicula(req.body);
        await pelicula.save();
        res.status(201).send(pelicula);
    } catch (error) {
        res.status(400).send(error);
    }
});

// leo todas las peliculas
router.get('/', async (req, res) => {
    try {
        const peliculas = await Pelicula.find();
        res.send(peliculas);
    } catch (error) {
        res.status(500).send(error);
    }
});

// actualizo pelicula x id
router.put('/:id', async (req, res) => {
    try {
        const pelicula = await Pelicula.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!pelicula) {
            return res.status(404).send();
        }
        res.send(pelicula);
    } catch (error) {
        res.status(400).send(error);
    }
});

// elimino pelicula x id
router.delete('/:id', async (req, res) => {
    try {
        const pelicula = await Pelicula.findByIdAndDelete(req.params.id);
        if (!pelicula) {
            return res.status(404).send();
        }
        res.send(pelicula);
    } catch (error) {
        res.status(500).send(error);
    }
});



module.exports = router;
